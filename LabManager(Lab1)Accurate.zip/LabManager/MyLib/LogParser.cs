﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace LogParserLib
{
    public class LogParser
    {
        public MatchCollection ParseLog(string selectedSignature, string textToSearch)
        {
            string pattern = $@"\b{Regex.Escape(selectedSignature)}\b";
            return Regex.Matches(textToSearch, pattern, RegexOptions.IgnoreCase);
        }
    }

    public class LogStringParser
    {
        public string ParseAndFormatEntry(string entry, DateTime start, DateTime end)
        {
            // Ищем дату и время в каждой записи
            Regex datePattern = new Regex(@"Date: (\d{2}.\d{2}.\d{4} \d{2}:\d{2}:\d{2})");
            Match dateMatch = datePattern.Match(entry);
            if (dateMatch.Success)
            {
                DateTime entryTime = DateTime.ParseExact(dateMatch.Groups[1].Value, "dd.MM.yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                // Проверяем, попадает ли время записи в заданный интервал
                if (entryTime >= start && entryTime <= end)
                {
                    // Если попадает, ищем все вхождения словоформы "string"
                    string formattedEntry = entry;
                    int offset = 0; // Используем смещение для корректной вставки "deg"

                    foreach (Match stringMatch in Regex.Matches(entry, "string", RegexOptions.IgnoreCase))
                    {
                        int startIndex = stringMatch.Index + offset;
                        formattedEntry = formattedEntry.Insert(startIndex + "string".Length, " async@gmail.com");
                        offset += " async@gmail.com".Length; // Увеличиваем смещение для следующей вставки
                    }

                    return formattedEntry;
                }
            }

            return entry; // Возвращаем исходную запись, если она не попадает в заданный интервал
        }
    }

    public class LogResult
    {
        public string FormName { get; set; }
        public string Date { get; set; }
        public string ExecutionTime { get; set; }
        public string MatchCount { get; set; }
    }


    public class LogEntryParser
    {
        public List<LogResult> ParseLogResults(string logText)
        {
            List<LogResult> results = new List<LogResult>();

            string pattern = @"Form name: (.+?)\. Date: (\d+\.\d+\.\d+ \d+:\d+:\d+)\s+Task running time: (\d+,\d+) ms\.\s+Signature: \w+, number of matches: (\d+)";
            var matches = Regex.Matches(logText, pattern, RegexOptions.Singleline);

            foreach (Match match in matches)
            {
                string formName = match.Groups[1].Value;
                string date = match.Groups[2].Value;
                string executionTime = match.Groups[3].Value;
                string matchCount = match.Groups[4].Value;

                results.Add(new LogResult
                {
                    FormName = formName,
                    Date = date,
                    ExecutionTime = executionTime,
                    MatchCount = matchCount
                });
            }

            return results;
        }
    }
}