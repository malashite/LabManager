﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogParserLib;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LabManager
{
    public partial class Lab1 : Form
    {
        LabManager f1;
        public Lab1()
        {
            InitializeComponent();
        }

        //Подключение к главной форме
        public Lab1(LabManager f)
        {
            InitializeComponent();
            f1 = f;
        }

        // Для хранения выбранной сигнатуры
        private string selectedSignature = null;

        //Словарь для цветов
        private Dictionary<string, Color> signatureColors = new Dictionary<string, Color>();

        //Открытие файла
        private async void OpenFile(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.Filter = "Text files(*.txt)|*.txt| All files(*.*)|*.*";
                if (openFileDialog1.ShowDialog() == DialogResult.Cancel) return;

                string FileName = openFileDialog1.FileName;
                using (StreamReader reader = File.OpenText(FileName))
                {
                    string FileText = await reader.ReadToEndAsync();
                    ShowText.Text = FileText;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                string exceptionText = $"{DateTime.Now}:{ex.InnerException},\n{ex.Message},\n{ex.Source},\n{ex.StackTrace},\n{ex.TargetSite}\n";
                using (StreamWriter writer = File.AppendText("log.txt"))
                {
                    await writer.WriteLineAsync(exceptionText);
                    writer.WriteLine(new string('-', 174));
                }
            }
        }


        //Сохранение логов
        private async Task SaveLogToFileAsync(string logEntry)
        {
            string logFileName = "log.txt";

            try
            {
                using (StreamWriter writer = File.AppendText(logFileName))
                {
                    await writer.WriteLineAsync(logEntry);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when saving the log: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        //Добавление сигнатур
        private void AddSignature(object sender, EventArgs e)
        {
            string newSignature = textBox1.Text;
            if (!comboBox1.Items.OfType<string>().Any(item => item.Equals(newSignature, StringComparison.OrdinalIgnoreCase)))
            {
                comboBox1.Items.Add(textBox1.Text);
                comboBox1.Sorted = true;
                comboBox1.SelectedItem = newSignature;
                textBox1.Text = "";

            }
            else
            {
                MessageBox.Show("Error: The string cannot be empty.\nThis signature has already been added.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = "";
            }
        }

        //Выделение вхождений
        private async Task SetSelectionStyleAsync(int address, int len, FontStyle style, Color select_color, RichTextBox source)
        {
            await Task.Run(() =>
            {
                source.Invoke((MethodInvoker)delegate
                {
                    source.Select(address, len);
                    source.SelectionFont = new Font(source.SelectionFont, source.SelectionFont.Style | style);
                    source.SelectionColor = select_color;
                });
            });
        }


        private void SignatureChanged(object sender, EventArgs e)
        {
            selectedSignature = comboBox1.SelectedItem as string;
        }

        //Парсинг лог журнала
        private async void SelectInclusions(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(selectedSignature))
                {
                    MessageBox.Show("Select a signature to search for inclusions.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                DateTime startTime = DateTime.Now;
                string textToSearch = ShowText.Text;
                string formName = "Lab1";
                string logEntry = $"Form name: {formName}. Date: {DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss")}";

                LogParser logParser = new LogParser();
                MatchCollection matches = logParser.ParseLog(selectedSignature, textToSearch);

                Random rand = new Random();
                Color randomColor = Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256));
                signatureColors[selectedSignature] = randomColor;

                if (matches.Count > 0)
                {
                    logEntry += $"\nTask running time: {(DateTime.Now - startTime).TotalMilliseconds} ms.";
                    logEntry += $"\nSignature: {selectedSignature}, number of matches: {matches.Count}";
                    logEntry += $"\nText of the work:\n{textToSearch}";

                    // Отправка информации в лог и сохранение в файл
                    logEntry += "\n" + new string('-', 174);
                    await SaveLogToFileAsync(logEntry);

                    // Вывод информации о включениях
                    ShowInclusionsTextBox.Text = $"All occurrences of the string '{selectedSignature}' in the source text:\r\n";

                    foreach (Match match in matches)
                    {
                        // Вызов SetSelectionStyle для выделения вхождений в ShowText
                        await SetSelectionStyleAsync(match.Index, match.Length, FontStyle.Bold, signatureColors[selectedSignature], ShowText);

                        // Добавление информации о включении в ShowInclusionsTextBox
                        ShowInclusionsTextBox.Text += $"({match.Index}) - {selectedSignature}\r\n";
                    }
                }
                else
                {
                    ShowInclusionsTextBox.Text = $"No occurrences of the string '{selectedSignature}' found in the source text.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                string exceptionText = $"{DateTime.Now}:{ex.InnerException},\n{ex.Message},\n{ex.Source},\n{ex.StackTrace},\n{ex.TargetSite}\n";
                using (StreamWriter writer = File.AppendText("log.txt"))
                {
                    await writer.WriteLineAsync(exceptionText);
                    writer.WriteLine(new string('-', 174));
                }
            }
        }

        //Парсинг лог журналов
        private async void StartParsing_Click(object sender, EventArgs e)
        {
            // Создаем экземпляр класса LogParser из DLL
            LogParser parser = new LogParser();

            // Получаем выбранную сигнатуру из comboBox
            string selectedSignature = comboBox1.SelectedItem.ToString();

            if (string.IsNullOrEmpty(selectedSignature))
            {
                MessageBox.Show("Select a signature before parsing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Получаем список файлов для парсинга
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "Text files(*.txt)|*.txt| All files(*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Запускаем таймер для измерения времени парсинга
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();

                StringBuilder results = new StringBuilder(); // Строитель строк для хранения результатов
                int totalMatches = 0; // Переменная для хранения общего количества совпадений

                foreach (string fileName in openFileDialog.FileNames)
                {
                    // Читаем текст из файла асинхронно
                    string textToSearch;
                    using (StreamReader sr = new StreamReader(fileName))
                    {
                        textToSearch = await sr.ReadToEndAsync();
                    }

                    // Вызываем функцию ParseLog из DLL
                    MatchCollection matches = parser.ParseLog(selectedSignature, textToSearch);

                    totalMatches += matches.Count; // Обновляем общее количество совпадений

                    // Добавляем результаты парсинга в results
                    results.AppendLine($"File: {Path.GetFileName(fileName)}");
                    results.AppendLine($"Content: {textToSearch}");
                    results.AppendLine();
                }

                // Останавливаем таймер и добавляем общее время парсинга в results
                stopwatch.Stop();
                string totalTime = $"Total parsing time: {stopwatch.Elapsed.TotalSeconds} seconds";

                // Выводим результаты в ShowBox с общим временем парсинга и общим количеством совпадений в начале
                ShowText.Text = $"{totalTime}\nTotal matches: {totalMatches}\n\n{results.ToString()}";
            }
        }
    }
}