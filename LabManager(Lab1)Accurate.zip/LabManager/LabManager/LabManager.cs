﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Hosting;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogParserLib;

namespace LabManager
{
    public partial class LabManager : Form
    {
        private StringBuilder logContent = new StringBuilder();
        private FileSystemWatcher logFileWatcher;
        ToolStripLabel dateLabel;
        ToolStripLabel timeLabel;
        ToolStripLabel infoLable;
        System.Windows.Forms.Timer timer;

        public LabManager()
        {
            InitializeComponent();

            InitializeLogMonitor();

            //status strip
            infoLable = new ToolStripLabel();
            infoLable.Text = "Current date and time: ";
            dateLabel = new ToolStripLabel();
            timeLabel = new ToolStripLabel();

            statusStrip1.Items.Add(infoLable);
            statusStrip1.Items.Add(dateLabel);
            statusStrip1.Items.Add(timeLabel);

            timer = new System.Windows.Forms.Timer() { Interval = 1000 };
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        //Наблюдение за изменениями лога
        private void InitializeLogMonitor()
        {
            logFileWatcher = new FileSystemWatcher();
            logFileWatcher.Path = Path.GetDirectoryName(Application.ExecutablePath);
            logFileWatcher.Filter = "log.txt";
            logFileWatcher.NotifyFilter = NotifyFilters.LastWrite;
            logFileWatcher.Changed += LogFileChanged;
            logFileWatcher.EnableRaisingEvents = true;

            string logFileName = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "log.txt");
            if (File.Exists(logFileName))
            {
                string logContent = File.ReadAllText(logFileName);
                LogBox.Text = logContent;
            }
        }

        //Изменение лога
        private async void LogFileChanged(object sender, FileSystemEventArgs e)
        {
            if (e.ChangeType == WatcherChangeTypes.Changed)
            {
                await Task.Delay(1000);

                string logFileName = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "log.txt");
                using (StreamReader reader = new StreamReader(logFileName))
                {
                    string logContent = await reader.ReadToEndAsync();
                    Invoke((MethodInvoker)(() => LogBox.Text = logContent));
                }
            }
        }

        //Сохранить файл
        private async void SaveFile_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";

            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel) { return; }

            string filename = saveFileDialog1.FileName;
            try
            {
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    await writer.WriteAsync(LogBox.Text);
                }
                MessageBox.Show("Files saved");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when saving the file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Открыть файл
        private async void OpenFile_click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.Filter = "Text files(*.txt)|*.txt| All files(*.*)|*.*";
                if (openFileDialog1.ShowDialog() == DialogResult.Cancel) return;

                string FileName = openFileDialog1.FileName;
                using (StreamReader reader = File.OpenText(FileName))
                {
                    string FileText = await reader.ReadToEndAsync();
                    LogBox.Text = FileText;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                string exceptionText = $"{DateTime.Now}:{ex.InnerException},\n{ex.Message},\n{ex.Source},\n{ex.StackTrace},\n{ex.TargetSite}\n";
                using (StreamWriter writer = File.AppendText("log.txt"))
                {
                    await writer.WriteLineAsync(exceptionText);
                    writer.WriteLine(new string('-', 174));
                }
            }
        }

        //Статусная строка
        void Timer_Tick(object sender, EventArgs e)
        {
            dateLabel.Text = DateTime.Now.ToLongDateString();
            timeLabel.Text = DateTime.Now.ToLongTimeString();
        }

        //Открыть форму
        private void Open_Lab1(object sender, EventArgs e)
        {
            Lab1 newForm = new Lab1(this);
            newForm.Show();
        }

        //Очистить лог
        private void ClearLogBox(object sender, EventArgs e)
        {
            File.WriteAllText("log.txt", "");
            LogBox.Clear();
        }
        
        //Выделение
        private void SetSelectionStyle(int address, int len, FontStyle style, Color select_color, RichTextBox source)
        {
            source.Select(address, len);
            source.SelectionFont = new Font(source.SelectionFont, source.SelectionFont.Style | style);
            source.SelectionColor = select_color;
        }

        //Отобразить результаты парсинга форм и выделить названия форм
        private void DisplayLogResults(object sender, EventArgs e)
        {
            try
            {
                string logText = LogBox.Text;

                LogParserLib.LogEntryParser logEntryParser = new LogParserLib.LogEntryParser();
                List<LogParserLib.LogResult> results = logEntryParser.ParseLogResults(logText);

                // Очистить результаты в ShowResultsTextBox
                ShowResultsTextBox.Text = "";

                foreach (var result in results)
                {
                    string formName = result.FormName;
                    string pattern = $"Form name: {Regex.Escape(formName)}"; // Создаем паттерн для поиска
                    var matches = Regex.Matches(logText, pattern, RegexOptions.Singleline);

                    foreach (Match match in matches)
                    {
                        int startIndex = match.Index;
                        int length = match.Length;
                        SetSelectionStyle(startIndex+11, length-11, FontStyle.Bold, Color.Red, LogBox);
                    }

                    ShowResultsTextBox.Text += $"Form name: {formName}\n";
                    ShowResultsTextBox.Text += $"Date: {result.Date}\n";
                    ShowResultsTextBox.Text += $"Execution time: {result.ExecutionTime} ms\n";
                    ShowResultsTextBox.Text += $"Number of matches: {result.MatchCount}\n";
                    ShowResultsTextBox.Text += new string('-', 59) + "\n";
                }

            }
            catch (Exception ex)
            {
                // Записать ошибку в файл log.txt
                string errorText = $"Error: {ex.Message}\n{ex.StackTrace}\n";
                using (StreamWriter writer = File.AppendText("log.txt"))
                {
                    writer.WriteLine(errorText);
                    writer.WriteLine(new string('-', 174));
                }
            }
        }

        //Найти включения string и выделить
        private void Find_Click(object sender, EventArgs e)
        {
            string logText = LogBox.Text;
            string[] logEntries = logText.Split(new string[] { new string('-', 174) }, StringSplitOptions.None); // Разделяем текст на отдельные записи

            LogBox.Clear();
            bool matchesFound = false; // Переменная для отслеживания наличия совпадений

            foreach (string entry in logEntries)
            {
                LogStringParser parser = new LogStringParser();
                string formattedEntry = parser.ParseAndFormatEntry(entry, StartDateTimePicker.Value, EndDateTimePicker.Value); // Вызываем функцию из DLL

                if (formattedEntry != null)
                {
                    // Добавляем отформатированную запись в LogBox
                    LogBox.AppendText(formattedEntry + new string('-', 174));

                    // Выделяем каждое вхождение красным и синим цветом
                    foreach (Match stringMatch in Regex.Matches(formattedEntry, "string", RegexOptions.IgnoreCase))
                    {
                        int startIndex = LogBox.Text.IndexOf(formattedEntry) + stringMatch.Index;
                        SetSelectionStyle(startIndex, "string".Length, FontStyle.Bold, Color.Red, LogBox);
                    }
                    foreach (Match stringMatch in Regex.Matches(formattedEntry, "async@gmail.com", RegexOptions.IgnoreCase))
                    {
                        int startIndex = LogBox.Text.IndexOf(formattedEntry) + stringMatch.Index;
                        SetSelectionStyle(startIndex, "async@gmail.com".Length, FontStyle.Bold, Color.Blue, LogBox);
                    }

                    matchesFound = true; // Устанавливаем флаг, что найдены совпадения
                }
                else
                {
                    // Восстановление текущего функционала при отсутствии записей в заданном интервале
                    LogBox.AppendText(entry + new string('-', 174));
                }
            }

            if (!matchesFound)
            {
                MessageBox.Show("Matches 'string' not found in the specified interval.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

 
